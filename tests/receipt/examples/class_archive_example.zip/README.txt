WHAT THIS FILE IS

A sealed record of one training cohort: every graded ballot receipt
the academy issued, the plain-text exhibit that goes with each one,
and the hash-chained ledger those receipts were written into.

Issuer:  (mixed) Westbrook Regional Training Academy; 11 receipts carry none
Cohort:  (mixed) WRTA-2026-OB-14; 11 receipts carry none
Built:   2026-09-23T07:51:27Z (UTC)
Holds:   12 receipts

WHAT A RECEIPT CLAIMS, IN ITS OWN WORDS

  Proves:           the score and the ballot are unaltered since the timestamp
  Does NOT prove:   the score is correct; the sim was not attempted before

Read that second line twice. This archive shows that the scores in
it have not been altered since they were issued. It says nothing
about whether any score is the right score. That is the grading
vendor's question and this archive does not touch it.

HOW TO CHECK IT YOURSELF

Verification is free, needs no account, and needs nothing from the
people who issued this. Two ways, either one is enough:

1. In your browser, nothing installed.
   Get the verifier page:
     https://arcaeon.io/verify-receipt
   Save it and open it. It runs entirely inside your browser and
   sends nothing anywhere, so it works with the network off. Drag
   the receipt files from cohort/ onto the page. It recomputes
   each digest and tells you, one line per receipt, whether the
   document still matches what was sealed.

2. At a command line.
     pip install arcaeon-receipt
     arcaeon-receipt verify --batch cohort/
   The ledger sits beside the receipts in that folder, so the
   sequence claim on each receipt is checked too. Exit code 0 means
   every receipt VERIFIED, 2 means at least one is BROKEN, 4 means
   nothing is BROKEN but the check COULD NOT LOOK at one or more.

CHECKING THAT NOTHING IN HERE WAS SWAPPED

MANIFEST.json lists every other file in this archive with the
sha256 of its bytes. On macOS or Linux:

     shasum -a 256 cohort/<filename>

On Windows PowerShell:

     Get-FileHash cohort\<filename> -Algorithm SHA256

Compare what comes back to the entry in the manifest. A receipt
that was edited after this archive was built will not match, and it
will also fail the digest check in step 1 or 2 above, which is the
check that matters: the manifest proves the archive is intact, and
the receipt proves itself.

WHAT IS IN THE FOLDERS

  MANIFEST.json       this archive's contents and their digests
  roster_report.csv   one row per trainee, for the coordinator
  cohort/             the export itself, copied here unchanged

Every file under that folder is a byte-for-byte copy of what the
academy holds. Nothing was reformatted on the way in; a receipt that
was rewritten in transit would still verify, and would still be the
wrong thing to hand you.

A RECEIPT THAT DOES NOT VERIFY IS STILL IN HERE

When this archive was built, of its 12 receipts: 12 VERIFIED,
0 BROKEN, and 0 COULD NOT LOOK.

Any receipt that failed is in here with the others and named on the
manifest with its verdict. An export that quietly dropped them would
be a brochure, not a record, and the receipt somebody is looking for
is usually the one that stopped verifying.

The verdicts above are about documents, not about people. They say
which files still match what was sealed. They are not a statement
about how anyone did.
